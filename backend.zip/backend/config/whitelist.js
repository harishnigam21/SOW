const whitelist = ["http://localhost:5173", "https://sow-front8472.vercel.app"];
module.exports = whitelist;
